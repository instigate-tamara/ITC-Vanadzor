#!/usr/bin/python

dict = {'Name': 'Vahan', 'Age': 29, 'Surname' : 'Levonyan'}
print dict;
print "Printing keys of the dictionary: ",  dict.keys();
print "Printing values  of the dictionary: ", dict.values();
print "Printing items  of the dictionary: ", dict.items();
