#!/usr/bin/python

team = {'name':['Vahan', 'Karen', 'Eduard'], 'gender':'male' }

print "keys()",team.keys()
print "values()",team.values()
print "items()",team.items()
print team[2]
